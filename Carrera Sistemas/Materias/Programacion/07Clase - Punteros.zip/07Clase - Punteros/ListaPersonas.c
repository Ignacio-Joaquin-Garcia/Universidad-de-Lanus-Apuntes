#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ListaPersonas.h"

void cargarPersonasVacias(ListaPersonasPtr e){
    for(int i = 0; i<100;i++){
        e->arrayPersonas[i] = cargarPersona(-1, "Vacio");
    }
};
VehiculoPtr buscarPatentes(ListaPersonasPtr e, int patenteBuscar){
    VehiculoPtr b = malloc(sizeof(struct Vehiculo));
    b = cargarVehiculo("No Encontrado", -1, -1, -1);
    for(int i = 0;i<100;i++){
        if(e->arrayPersonas[i]->dni != -1){
            for(int j=0; j<5;j++){
                if(e->arrayPersonas[i]->vehiculosEnPosesion[j]->patente != -1){
                    if(e->arrayPersonas[i]->vehiculosEnPosesion[j]->patente == patenteBuscar){
                        b = e->arrayPersonas[i]->vehiculosEnPosesion[j];
                    }
                }
            }
        }
    }
    return b;
};
ListaPersonasPtr cargarPersonas(int cantPersonas){
    //Cargamos todas las personas como vacias
    ListaPersonasPtr e = malloc(sizeof(struct ListaPersonas));
    cargarPersonasVacias(e);
    for(int i = 0; i<cantPersonas; i++){
        e->arrayPersonas[i] = cargarPersonaPorTeclado(e->arrayPersonas[i]);

        //A�adimos Vehiculos Iniciales de la persona
        int pararIngreso;
        printf("\nDesea A�adir un Vehiculo a esta Persona (1:si/0:no): ");
        scanf("%d", &pararIngreso);
        while(!(pararIngreso == 0 || pararIngreso == 1)){
            printf("\n\tIngrese un valor correcto (1:si/0:no): ");
            scanf("%d", &pararIngreso);
        }

        int j = 0;
        while((j<5) && pararIngreso){
            cargarVehiculoPorTeclado(e->arrayPersonas[i]->vehiculosEnPosesion[j]);

            printf("Desea A�adir otro Vehiculo a esta Persona (1:si/0:no)?");
            scanf("%d", &pararIngreso);
            while(!(pararIngreso == 0 || pararIngreso == 1)){
                printf("Ingrese un valor correcto (1:si/0:no)?");
                scanf("%d", &pararIngreso);
            }
            j++;
        }
    }
    return e;
};
void mostrarPersonas(ListaPersonasPtr e, int cantPersonas){
    for(int i = 0; i<cantPersonas;i++){
        mostrarPersona(e->arrayPersonas[i]);
    }
};
ListaPersonasPtr ordernarVehiculoPorPrecio(ListaPersonasPtr e, int cantPersonas){
    for(int i = 0; i<cantPersonas;i++){
        e->arrayPersonas[i] = ordenarVehiculoPorPrecio(e->arrayPersonas[i]);
    }
    return e;
};
